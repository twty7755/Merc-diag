package com.example.mbobd

/**
 * Engine profiles and fault-code hints for the Mercedes M112 (V6) and M113 (V8) families.
 * Hints are general guidance about commonly reported causes, not a substitute for the
 * factory service manual (WIS/STAR).
 */
object Mercedes {
    class Engine(val label: String, val litres: Double, val cylinders: Int, val charged: Boolean)

    val ENGINES = listOf(
        Engine("M112 E24 - 2.4L V6", 2.4, 6, false),
        Engine("M112 E26 - 2.6L V6", 2.6, 6, false),
        Engine("M112 E28 - 2.8L V6", 2.8, 6, false),
        Engine("M112 E32 - 3.2L V6", 3.2, 6, false),
        Engine("M112 E32 ML - 3.2L V6 supercharged", 3.2, 6, true),
        Engine("M112 E37 - 3.7L V6", 3.7, 6, false),
        Engine("M113 E43 - 4.3L V8", 4.3, 8, false),
        Engine("M113 E50 - 5.0L V8", 5.0, 8, false),
        Engine("M113 E55 - 5.4/5.5L V8", 5.4, 8, false),
        Engine("M113 E55 K - 5.4/5.5L V8 supercharged", 5.4, 8, true)
    )

    private val names = mapOf(
        "P0100" to "MAF circuit", "P0101" to "MAF range/performance", "P0102" to "MAF circuit low",
        "P0103" to "MAF circuit high", "P0110" to "Intake air temp circuit", "P0112" to "Intake air temp low",
        "P0113" to "Intake air temp high", "P0115" to "Coolant temp circuit", "P0117" to "Coolant temp low",
        "P0118" to "Coolant temp high", "P0120" to "Throttle/pedal sensor circuit",
        "P0121" to "Throttle/pedal sensor range", "P0122" to "Throttle/pedal sensor low",
        "P0123" to "Throttle/pedal sensor high", "P0125" to "Coolant too cold for closed loop",
        "P0128" to "Coolant below thermostat regulating temp",
        "P0170" to "Fuel trim malfunction bank 1", "P0171" to "System too lean bank 1",
        "P0172" to "System too rich bank 1", "P0173" to "Fuel trim malfunction bank 2",
        "P0174" to "System too lean bank 2", "P0175" to "System too rich bank 2",
        "P0300" to "Random/multiple cylinder misfire",
        "P0335" to "Crankshaft position sensor circuit", "P0336" to "Crankshaft position sensor range",
        "P0340" to "Camshaft position sensor circuit bank 1", "P0341" to "Camshaft position sensor range bank 1",
        "P0345" to "Camshaft position sensor circuit bank 2", "P0346" to "Camshaft position sensor range bank 2",
        "P0410" to "Secondary air injection system", "P0411" to "Secondary air injection incorrect flow",
        "P0412" to "Secondary air switching valve circuit", "P0418" to "Secondary air pump relay circuit",
        "P0420" to "Catalyst efficiency below threshold bank 1", "P0430" to "Catalyst efficiency below threshold bank 2",
        "P0440" to "EVAP system", "P0441" to "EVAP incorrect purge flow", "P0442" to "EVAP small leak",
        "P0443" to "EVAP purge valve circuit", "P0446" to "EVAP vent control circuit",
        "P0455" to "EVAP large leak", "P0456" to "EVAP very small leak",
        "P0500" to "Vehicle speed sensor", "P0505" to "Idle control system", "P0506" to "Idle speed lower than expected",
        "P0507" to "Idle speed higher than expected", "P0560" to "System voltage",
        "P0601" to "Control module memory checksum", "P0606" to "Control module processor",
        "P0700" to "Transmission control system request"
    )

    /**
     * Generic O2 sensor codes. Sensor 1 (upstream) uses P0130-P0135 / P0150-P0155 in the order
     * circuit, low, high, slow, no activity, heater. Sensor 2 (downstream) uses P0136-P0139 for
     * circuit/low/high/slow, then P0140 no activity and P0141 heater; bank 2 is P0156-P0159,
     * P0160, P0161. Codes in between (P013A etc.) are not labelled here.
     */
    private fun o2Name(n: Int): String? {
        val (sensor, base) = when (n) {
            in 0x130..0x135 -> "bank 1 sensor 1" to 0x130
            in 0x136..0x139, 0x140, 0x141 -> "bank 1 sensor 2" to 0x136
            in 0x150..0x155 -> "bank 2 sensor 1" to 0x150
            in 0x156..0x159, 0x160, 0x161 -> "bank 2 sensor 2" to 0x156
            else -> return null
        }
        val what = if (sensor.endsWith("sensor 1")) {
            when (n - base) {
                0 -> "circuit"; 1 -> "low voltage"; 2 -> "high voltage"
                3 -> "slow response"; 4 -> "no activity"; 5 -> "heater circuit"
                else -> return null
            }
        } else {
            when (n) {
                base -> "circuit"
                base + 1 -> "low voltage"
                base + 2 -> "high voltage"
                base + 3 -> "slow response"
                0x140, 0x160 -> "no activity"
                0x141, 0x161 -> "heater circuit"
                else -> return null
            }
        }
        return "O2 sensor $what ($sensor)"
    }

    private fun name(code: String): String? {
        names[code]?.let { return it }
        if (code.length == 5 && code.startsWith("P0")) {
            val n = code.substring(1).toIntOrNull(16)
            if (n != null) {
                o2Name(n)?.let { return it }
                if (n in 0x301..0x308) return "Cylinder ${n - 0x300} misfire"
                if (n in 0x351..0x358) return "Ignition coil ${'A' + (n - 0x351)} circuit"
            }
        }
        return null
    }

    private fun hint(code: String, e: Engine): String? {
        val twin = "Twin-spark engine: each cylinder has two plugs and coils. Check both on the reported cylinder; swap coils between cylinders to confirm."
        return when {
            code in listOf("P0171", "P0174") ->
                "Lean. Both banks: check crankcase breather/vent hoses, intake leaks after the MAF, hot-film MAF contamination, fuel pressure. One bank: leaks or injector/coil/O2 on that side."
            code in listOf("P0172", "P0175") ->
                "Rich. Check fuel pressure/regulator, leaking injectors, purge valve stuck open, coolant temp sensor reading cold, restricted air filter."
            code == "P0300" -> "Random misfire. $twin Also check fuel delivery and vacuum leaks."
            code.startsWith("P030") -> twin
            code.startsWith("P035") -> "Coil circuit: check coil connector, wiring and the coil itself."
            code.startsWith("P041") || code.startsWith("P0418") ->
                "Secondary air system: check pump fuse/relay, pump operation, clogged combi/check valves, vacuum/solenoid supply."
            code in listOf("P0420", "P0430") ->
                "Catalyst: check for exhaust leaks and failing downstream O2 sensor first; confirm with O2 waveform before replacing a cat."
            code.startsWith("P013") || code.startsWith("P014") || code.startsWith("P015") || code.startsWith("P016") ->
                "O2 sensor: check wiring/connector and heater supply, exhaust leaks ahead of the sensor, sensor age."
            code in listOf("P0100", "P0101", "P0102", "P0103") ->
                "Hot-film MAF: check connector, contamination, air leaks around the intake, air filter housing."
            code.startsWith("P0335") || code.startsWith("P0336") || code.startsWith("P0340") ||
                code.startsWith("P0341") || code.startsWith("P0345") || code.startsWith("P0346") ->
                "Crank/cam sensor: check sensor, connector, wiring and engine oil contamination at the sensor."
            code.startsWith("P001") || code.startsWith("P002") ->
                "Camshaft timing/adjuster: check oil level and condition, adjuster solenoid and connector, adjuster operation."
            code.startsWith("P012") -> "Electronic throttle/pedal: check connector and wiring, clean throttle body, perform throttle adaption if required."
            code in listOf("P0125", "P0128") -> "Thermostat stuck open or coolant temp sensor fault."
            code.startsWith("P044") || code.startsWith("P045") ->
                "EVAP: check fuel cap and seal, purge and vent valves, hoses to the tank."
            code.startsWith("P050") -> "Idle control: check throttle body, vacuum leaks, idle adaption."
            code == "P0560" -> "Voltage: check battery, charging output, grounds."
            code.startsWith("P06") -> "Control module internal fault: check power/ground, then ECU."
            code == "P0700" -> "Transmission requested the MIL: read the transmission module for its own codes."
            code.startsWith("U") -> "Network fault: check module power/grounds, CAN wiring, and any module that is offline."
            code.startsWith("P1") || code.startsWith("P2") && code != "P2" ->
                "Manufacturer/enhanced code: decode with Mercedes WIS/STAR for the exact meaning."
            else -> null
        }
    }

    fun describe(code: String, e: Engine): String {
        val n = name(code)
        val h = hint(code, e)
        val sb = StringBuilder(code)
        if (n != null) sb.append(" - ").append(n)
        if (h != null) sb.append("\n      ").append(h)
        return sb.toString()
    }
}
