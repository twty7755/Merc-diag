package com.example.mbobd

import java.io.ByteArrayOutputStream
import java.util.Locale

/** Scan logic on top of an ELM327 link. Everything here is read-only except clearCodes(). */
class Scanner(private val link: ObdLink, private val log: (String) -> Unit) {
    var isCan = false
        private set
    var protoNum = "0"
        private set
    var protoDesc = ""
        private set
    var supported: Set<Int> = emptySet()
        private set

    class Stat(val min: Double, val avg: Double, val max: Double)

    // ---------- adapter / ECU setup ----------

    fun init(): String {
        link.send("ATZ", 3500)
        link.send("ATE0"); link.send("ATL0"); link.send("ATS0"); link.send("ATH0")
        link.send("ATAT1"); link.send("ATSP0")
        return link.send("ATI").firstOrNull { it.contains("ELM", true) } ?: "unknown adapter"
    }

    fun connectEcu(): Boolean {
        repeat(2) {
            val m = Obd.messages(link.send("01 00", 15000))
            if (Obd.find(m, 1, 0x00) != null) {
                detectProtocol()
                return true
            }
        }
        return false
    }

    private fun detectProtocol() {
        val p = link.send("ATDPN").firstOrNull()?.trim()?.uppercase() ?: return
        protoNum = if (p.length >= 2 && p[0] == 'A') p.substring(1, 2) else p.take(1)
        isCan = protoNum.isNotEmpty() && protoNum[0] in "6789ABC"
        protoDesc = link.send("ATDP").firstOrNull() ?: protoNum
    }

    private fun restoreDefaults() {
        link.send("ATD"); link.send("ATE0"); link.send("ATL0"); link.send("ATS0"); link.send("ATH0")
        link.send("ATAT1"); link.send("ATSP$protoNum")
    }

    // ---------- PIDs ----------

    fun loadSupported(): Set<Int> {
        val set = HashSet<Int>()
        var base = 0x00
        while (base <= 0x60) {
            val m = Obd.find(Obd.messages(link.send("01 %02X".format(base), 4000)), 1, base) ?: break
            if (m.size < 6) break
            var mask = 0L
            for (i in 2..5) mask = (mask shl 8) or Obd.u(m[i]).toLong()
            for (i in 0 until 32) if ((mask shr (31 - i)) and 1L == 1L) set.add(base + i + 1)
            if ((base + 0x20) !in set) break
            base += 0x20
        }
        supported = set
        return set
    }

    fun readPid(id: Int): Double? {
        val d = Obd.pid(id) ?: return null
        val m = Obd.find(Obd.messages(link.send("01 %02X".format(id), 3000)), 1, id) ?: return null
        if (m.size < 2 + d.bytes) return null
        return d.decode(IntArray(d.bytes) { Obd.u(m[2 + it]) })
    }

    // ---------- quick scan ----------

    fun quickScan(e: Mercedes.Engine): List<String> {
        log("== QUICK SCAN ==")
        log("Engine profile: ${e.label}")
        log("Protocol: $protoDesc")
        if (supported.isEmpty()) loadSupported()
        log("Supported live PIDs: ${supported.size}")
        readIdentity()
        readStatus()
        val all = LinkedHashSet<String>()
        all += readDtcs(0x03, "Stored codes", e)
        all += readDtcs(0x07, "Pending codes", e)
        all += readDtcs(0x0A, "Permanent codes", e)
        if (all.isNotEmpty()) readFreezeFrame()
        return all.toList()
    }

    private fun readIdentity() {
        val vin = Obd.messages(link.send("09 02", 6000)).filter {
            it.size >= 3 && Obd.u(it[0]) == 0x49 && Obd.u(it[1]) == 0x02
        }
        val bytes = ByteArrayOutputStream()
        for (m in vin) bytes.write(m, 3, m.size - 3)
        var v = bytes.toByteArray().filter {
            val c = Obd.u(it); c in 0x30..0x39 || c in 0x41..0x5A
        }.map { Obd.u(it).toChar() }.joinToString("")
        if (v.length > 17) v = v.takeLast(17)
        log("VIN: ${v.ifEmpty { "not reported" }}")

        val cal = Obd.messages(link.send("09 04", 6000)).filter {
            it.size >= 3 && Obd.u(it[0]) == 0x49 && Obd.u(it[1]) == 0x04
        }
        val cb = ByteArrayOutputStream()
        for (m in cal) cb.write(m, 3, m.size - 3)
        val calId = Obd.asciiFrom(cb.toByteArray(), 0)
        if (calId.isNotEmpty()) log("ECU calibration ID: $calId")
    }

    private fun readStatus() {
        val m = Obd.find(Obd.messages(link.send("01 01", 4000)), 1, 0x01)
        if (m == null || m.size < 6) { log("MIL status: not available"); return }
        val a = Obd.u(m[2]); val b = Obd.u(m[3]); val c = Obd.u(m[4]); val d = Obd.u(m[5])
        log("MIL: ${if (a and 0x80 != 0) "ON" else "off"}   Stored code count: ${a and 0x7F}")
        val notDone = ArrayList<String>()
        val done = ArrayList<String>()
        fun add(sup: Boolean, inc: Boolean, n: String) {
            if (sup) { if (inc) notDone.add(n) else done.add(n) }
        }
        add(b and 0x01 != 0, b and 0x10 != 0, "Misfire")
        add(b and 0x02 != 0, b and 0x20 != 0, "Fuel system")
        add(b and 0x04 != 0, b and 0x40 != 0, "Components")
        val names = listOf("Catalyst", "Heated catalyst", "EVAP", "Secondary air", "A/C", "O2 sensor", "O2 heater", "EGR")
        for (i in names.indices) add(c and (1 shl i) != 0, d and (1 shl i) != 0, names[i])
        log("Monitors complete: ${done.joinToString().ifEmpty { "none" }}")
        log("Monitors NOT complete: ${notDone.joinToString().ifEmpty { "none" }}")
    }

    private fun readDtcs(mode: Int, title: String, e: Mercedes.Engine): List<String> {
        val msgs = Obd.messages(link.send("%02X".format(mode), 6000))
        val codes = LinkedHashSet<String>()
        for (m in msgs) if (m.isNotEmpty() && Obd.u(m[0]) == mode + 0x40) codes += Obd.decodeDtcs(m, isCan)
        if (codes.isEmpty()) {
            log("$title: none")
        } else {
            log("$title (${codes.size}):")
            codes.forEach { log("  " + Mercedes.describe(it, e)) }
        }
        return codes.toList()
    }

    private fun readFreezeFrame() {
        val sb = StringBuilder()
        for (id in listOf(0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0F, 0x10)) {
            val d = Obd.pid(id) ?: continue
            val m = Obd.find(Obd.messages(link.send("02 %02X 00".format(id), 3000)), 2, id) ?: continue
            if (m.size < 3 + d.bytes) continue
            val v = d.decode(IntArray(d.bytes) { Obd.u(m[3 + it]) })
            sb.append("  ").append(d.name).append(": ").append(Obd.f1(v)).append(' ').append(d.unit).append('\n')
        }
        if (sb.isNotEmpty()) {
            log("Freeze frame (conditions when the first code set):")
            log(sb.toString().trimEnd())
        }
    }

    // ---------- clear ----------

    fun clearCodes(): Boolean {
        val r = Obd.messages(link.send("04", 6000))
        return r.any { it.isNotEmpty() && Obd.u(it[0]) == 0x44 }
    }

    // ---------- live data ----------

    fun live(running: () -> Boolean, show: (String) -> Unit) {
        if (supported.isEmpty()) loadSupported()
        val ids = listOf(0x0C, 0x05, 0x04, 0x11, 0x0B, 0x10, 0x06, 0x07, 0x08, 0x09, 0x14, 0x18, 0x15, 0x19, 0x0E, 0x42, 0x0F, 0x0D)
            .filter { it in supported }
        if (ids.isEmpty()) { show("No supported live PIDs."); return }
        while (running()) {
            val sb = StringBuilder("LIVE DATA (tap Live again to stop)\n\n")
            for (id in ids) {
                if (!running()) return
                val p = Obd.pid(id) ?: continue
                val v = readPid(id)
                sb.append(String.format(Locale.US, "%-16s %s\n", p.name, if (v == null) "--" else Obd.f1(v) + " " + p.unit))
            }
            show(sb.toString())
        }
    }

    // ---------- deep scan part 1: sensor / fuel trim health ----------

    fun sensorHealth(e: Mercedes.Engine) {
        log("")
        log("== SENSOR AND FUEL TRIM HEALTH ==")
        log("Needs a warm engine (coolant 80C+) idling with A/C and loads off. Sampling about 15 seconds...")
        val ids = listOf(0x05, 0x0C, 0x42, 0x0B, 0x10, 0x06, 0x07, 0x08, 0x09, 0x14, 0x15, 0x18, 0x19, 0x0E, 0x04, 0x11)
            .filter { it in supported }
        if (ids.isEmpty()) { log("No supported live PIDs to sample."); return }
        val data = HashMap<Int, MutableList<Double>>()
        repeat(8) {
            for (id in ids) readPid(id)?.let { data.getOrPut(id) { ArrayList() }.add(it) }
        }
        val st = HashMap<Int, Stat>()
        for ((id, v) in data) if (v.isNotEmpty()) st[id] = Stat(v.min(), v.average(), v.max())

        for (id in ids) {
            val s = st[id] ?: continue
            val p = Obd.pid(id) ?: continue
            log(String.format(Locale.US, "  %-16s min %7.1f  avg %7.1f  max %7.1f %s", p.name, s.min, s.avg, s.max, p.unit))
        }

        val f = ArrayList<String>()
        val ect = st[0x05]
        val warm = ect == null || ect.avg >= 75
        if (ect != null) {
            when {
                ect.avg < 70 -> f += "[INFO] Coolant only ${Obd.f1(ect.avg)}C: engine not warm, so trim and O2 results are unreliable. Re-run when warm."
                ect.avg < 80 -> f += "[CHECK] Coolant ${Obd.f1(ect.avg)}C is low for a warm engine. If it has run 15+ minutes, suspect a stuck-open thermostat."
                ect.avg > 108 -> f += "[WARN] Coolant ${Obd.f1(ect.avg)}C is high: check fans, coolant level, thermostat."
                else -> f += "[OK] Coolant temperature normal (${Obd.f1(ect.avg)}C)."
            }
        }
        st[0x42]?.let {
            f += when {
                it.avg < 13.2 -> "[CHECK] Voltage ${Obd.f1(it.avg)}V at idle is low: charging system, battery, grounds."
                it.avg > 14.9 -> "[CHECK] Voltage ${Obd.f1(it.avg)}V at idle is high: regulator/alternator."
                else -> "[OK] Charging voltage ${Obd.f1(it.avg)}V."
            }
        }
        st[0x0C]?.let {
            if (it.avg < 550 || it.avg > 900) f += "[CHECK] Idle speed ${Obd.f1(it.avg)} rpm is outside the usual 550-900 range."
            if (it.max - it.min > 100) f += "[CHECK] Idle speed swings ${Obd.f1(it.max - it.min)} rpm: vacuum leak, dirty throttle body, misfire, or idle adaption needed."
            else f += "[OK] Idle speed stable."
        }
        st[0x0B]?.let {
            if (it.avg > 55) f += "[CHECK] Manifold pressure ${Obd.f1(it.avg)} kPa at idle is high: vacuum leak or low engine vacuum."
            else f += "[OK] Idle manifold pressure ${Obd.f1(it.avg)} kPa."
        }
        st[0x10]?.let {
            val lo = e.litres * 0.8
            val hi = e.litres * 1.6
            when {
                it.avg < lo -> f += "[CHECK] MAF ${Obd.f1(it.avg)} g/s is low for ${e.litres}L (rule of thumb ${Obd.f1(lo)}-${Obd.f1(hi)}): dirty or failing hot-film MAF, or restricted intake."
                it.avg > hi -> f += "[CHECK] MAF ${Obd.f1(it.avg)} g/s is high for ${e.litres}L: check engine load, throttle position, MAF over-reading."
                else -> f += "[OK] MAF ${Obd.f1(it.avg)} g/s plausible for ${e.litres}L."
            }
        }

        if (warm) {
            val l1 = st[0x07]?.avg; val l2 = st[0x09]?.avg
            val s1 = st[0x06]; val s2 = st[0x08]
            if (l1 != null && l2 != null) {
                when {
                    l1 > 10 && l2 > 10 -> f += "[WARN] Both banks lean (LTFT ${Obd.f1(l1)}% / ${Obd.f1(l2)}%): common causes are crankcase breather hoses, intake leaks after the MAF, dirty MAF, low fuel pressure. Compare LTFT at 2500 rpm: leaks improve with revs, MAF or fuel delivery faults do not."
                    l1 < -10 && l2 < -10 -> f += "[WARN] Both banks rich (LTFT ${Obd.f1(l1)}% / ${Obd.f1(l2)}%): check fuel pressure, leaking injectors, purge valve stuck open, coolant sensor."
                    Math.abs(l1) > 10 && Math.abs(l2) <= 6 -> f += "[WARN] Bank 1 only (LTFT ${Obd.f1(l1)}%): look at that bank's injectors, coils/plugs, O2 sensor, local leaks."
                    Math.abs(l2) > 10 && Math.abs(l1) <= 6 -> f += "[WARN] Bank 2 only (LTFT ${Obd.f1(l2)}%): look at that bank's injectors, coils/plugs, O2 sensor, local leaks."
                    Math.abs(l1) > 6 || Math.abs(l2) > 6 -> f += "[INFO] Mild long-term trim (${Obd.f1(l1)}% / ${Obd.f1(l2)}%). Worth watching."
                    else -> f += "[OK] Long-term trims normal (${Obd.f1(l1)}% / ${Obd.f1(l2)}%)."
                }
            } else if (l1 != null) {
                f += if (Math.abs(l1) > 10) "[WARN] LTFT bank 1 ${Obd.f1(l1)}%: outside +/-10%." else "[OK] LTFT bank 1 ${Obd.f1(l1)}%."
            }
            for ((label, s) in listOf("bank 1" to s1, "bank 2" to s2)) {
                if (s != null && s.max - s.min > 15) {
                    f += "[CHECK] Short-term trim $label swings ${Obd.f1(s.max - s.min)}%: sluggish O2 sensor, misfire, or erratic fueling."
                }
            }
            for ((label, id) in listOf("B1S1" to 0x14, "B2S1" to 0x18)) {
                val s = st[id] ?: continue
                when {
                    s.max - s.min < 0.3 && s.avg > 0.75 -> f += "[CHECK] Upstream O2 $label stuck high (${Obd.f1(s.avg)}V): rich condition or failed sensor."
                    s.max - s.min < 0.3 && s.avg < 0.25 -> f += "[CHECK] Upstream O2 $label stuck low (${Obd.f1(s.avg)}V): lean condition, exhaust leak, or failed sensor."
                    s.max - s.min < 0.3 -> f += "[CHECK] Upstream O2 $label barely switches (${Obd.f1(s.min)}-${Obd.f1(s.max)}V): lazy sensor."
                    else -> f += "[OK] Upstream O2 $label switching (${Obd.f1(s.min)}-${Obd.f1(s.max)}V)."
                }
            }
            for ((label, up, down) in listOf(Triple("bank 1", 0x14, 0x15), Triple("bank 2", 0x18, 0x19))) {
                val u = st[up]; val d = st[down]
                if (u != null && d != null && d.max - d.min > 0.5 && u.max - u.min > 0.5) {
                    f += "[CHECK] Downstream O2 $label switches almost as much as upstream: catalyst may be worn (see P0420/P0430)."
                }
            }
        }

        log("")
        log("Findings:")
        f.forEach { log("  $it") }
        log("Notes: narrowband O2 PIDs only; wideband sensors on some cars use other PIDs. Thresholds are rules of thumb.")
    }

    // ---------- deep scan part 2: module sweep (CAN) ----------

    fun moduleSweep(e: Mercedes.Engine) {
        log("")
        log("== MODULE SWEEP ==")
        if (!isCan || protoNum != "6") {
            log("[INFO] Protocol is $protoDesc. The sweep needs 11-bit 500k CAN (ISO 15765-4). On older K-line cars an ELM327 can only talk to the engine ECU on the OBD-II pins.")
            return
        }
        log("Probing CAN request IDs 700-7F7 with a harmless TesterPresent (3E 00). About a minute...")
        val found = ArrayList<Int>()
        link.send("ATS1"); link.send("ATH1"); link.send("ATAT0"); link.send("ATST 19")
        for (tx in 0x700..0x7F7) {
            if (tx == 0x7DF) continue
            val rx = tx + 8
            link.send("ATSH %03X".format(tx), 1000)
            link.send("ATCRA %03X".format(rx), 1000)
            val r = link.send("3E 00", 800)
            val rxHex = "%03X".format(rx)
            val hit = r.any { line ->
                val t = line.trim().split(' ').filter { it.isNotEmpty() }
                t.size >= 3 && t[0].equals(rxHex, true) &&
                    t.drop(1).all { it.length == 2 && it.all { c -> c in "0123456789ABCDEFabcdef" } }
            }
            if (hit) {
                found.add(tx)
                log("  Module answered: request %03X, reply %s".format(tx, rxHex))
            }
            if (tx % 0x40 == 0x3F) log("  ...swept to %03X".format(tx))
        }
        link.send("ATS0"); link.send("ATH0"); link.send("ATAT1"); link.send("ATST 64")

        if (found.isEmpty()) {
            log("No modules answered. The adapter may only see the engine bus, or modules sit behind a gateway that needs Mercedes-specific access.")
            restoreDefaults()
            return
        }
        for (tx in found) {
            link.send("ATSH %03X".format(tx), 1000)
            link.send("ATCRA %03X".format(tx + 8), 1000)
            log("")
            log("Module %03X:".format(tx))
            for ((did, label) in listOf(0xF190 to "VIN", 0xF187 to "Part number", 0xF194 to "Software number", 0xF18C to "Serial")) {
                val m = Obd.messages(link.send("22 %04X".format(did), 2500))
                    .firstOrNull { it.size >= 4 && Obd.u(it[0]) == 0x62 }
                val s = if (m != null) Obd.asciiFrom(m, 3) else ""
                if (s.isNotEmpty()) log("  $label: $s")
            }
            readModuleDtcs(tx, e)
        }
        restoreDefaults()
    }

    private fun readModuleDtcs(tx: Int, e: Mercedes.Engine) {
        val uds = Obd.messages(link.send("19 02 FF", 3500)).firstOrNull { it.size >= 3 && Obd.u(it[0]) == 0x59 }
        if (uds != null) {
            val codes = ArrayList<String>()
            var i = 3
            while (i + 3 < uds.size) {
                val code = Obd.dtcString(Obd.u(uds[i]), Obd.u(uds[i + 1])) + "-%02X".format(Obd.u(uds[i + 2]))
                codes.add(code + " (status %02X)".format(Obd.u(uds[i + 3])))
                i += 4
            }
            logDtcList("UDS", codes)
            return
        }
        val kwp = Obd.messages(link.send("18 00 FF 00", 3500)).firstOrNull { it.size >= 2 && Obd.u(it[0]) == 0x58 }
        if (kwp != null) {
            val codes = ArrayList<String>()
            var i = 2
            while (i + 2 < kwp.size) {
                codes.add(Obd.dtcString(Obd.u(kwp[i]), Obd.u(kwp[i + 1])) + " (status %02X)".format(Obd.u(kwp[i + 2])))
                i += 3
            }
            logDtcList("KWP2000", codes)
            return
        }
        if (tx in 0x7E0..0x7E7) {
            val codes = LinkedHashSet<String>()
            for (m in Obd.messages(link.send("03", 4000))) {
                if (m.isNotEmpty() && Obd.u(m[0]) == 0x43) codes += Obd.decodeDtcs(m, true)
            }
            if (codes.isEmpty()) log("  Stored codes (OBD-II): none")
            else { log("  Stored codes (OBD-II):"); codes.forEach { log("    " + Mercedes.describe(it, e)) } }
            return
        }
        log("  Module did not answer UDS or KWP2000 DTC requests (it may need a Mercedes-specific session).")
    }

    private fun logDtcList(kind: String, codes: List<String>) {
        if (codes.isEmpty()) log("  DTCs ($kind): none")
        else { log("  DTCs ($kind, ${codes.size}):"); codes.forEach { log("    $it") } }
    }

    // ---------- full deep scan ----------

    fun deepScan(e: Mercedes.Engine) {
        quickScan(e)
        sensorHealth(e)
        moduleSweep(e)
        log("")
        log("== DEEP SCAN DONE ==")
    }
}
