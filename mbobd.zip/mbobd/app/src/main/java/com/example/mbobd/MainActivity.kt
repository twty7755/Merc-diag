package com.example.mbobd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var deviceSpinner: Spinner
    private lateinit var engineSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private lateinit var connectBtn: Button
    private lateinit var quickBtn: Button
    private lateinit var deepBtn: Button
    private lateinit var liveBtn: Button
    private lateinit var clearBtn: Button

    private val link = ObdLink()
    private val io = Executors.newSingleThreadExecutor()
    private val report = StringBuilder()
    private var devices: List<BluetoothDevice> = emptyList()

    @Volatile private var liveRunning = false

    private val scanner = Scanner(link) { line -> log(line) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadDevices() else status.text = "Bluetooth permission is required."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        deviceSpinner = findViewById(R.id.deviceSpinner)
        engineSpinner = findViewById(R.id.engineSpinner)
        status = findViewById(R.id.status)
        output = findViewById(R.id.output)
        scroll = findViewById(R.id.scroll)
        connectBtn = findViewById(R.id.connectBtn)
        quickBtn = findViewById(R.id.quickBtn)
        deepBtn = findViewById(R.id.deepBtn)
        liveBtn = findViewById(R.id.liveBtn)
        clearBtn = findViewById(R.id.clearBtn)

        engineSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Mercedes.ENGINES.map { it.label }
        )
        val prefs = getSharedPreferences("mbobd", Context.MODE_PRIVATE)
        engineSpinner.setSelection(prefs.getInt("engine", 3).coerceIn(0, Mercedes.ENGINES.size - 1))

        connectBtn.setOnClickListener { connect() }
        quickBtn.setOnClickListener {
            val e = engine(); prefs.edit().putInt("engine", engineSpinner.selectedItemPosition).apply()
            runTask(true) { scanner.quickScan(e) }
        }
        deepBtn.setOnClickListener {
            val e = engine(); prefs.edit().putInt("engine", engineSpinner.selectedItemPosition).apply()
            runTask(true) { scanner.deepScan(e) }
        }
        liveBtn.setOnClickListener {
            if (liveRunning) {
                liveRunning = false
            } else {
                liveRunning = true
                io.execute {
                    try {
                        scanner.live({ liveRunning }) { text -> runOnUiThread { output.text = text } }
                    } catch (ex: Exception) {
                        log("[ERROR] ${ex.message ?: ex.javaClass.simpleName}")
                    }
                    liveRunning = false
                }
            }
        }
        clearBtn.setOnClickListener { confirmClear() }
        findViewById<Button>(R.id.shareBtn).setOnClickListener { share() }

        output.text = "1. Pair your ELM327 adapter in Android Bluetooth settings (PIN is usually 1234 or 0000).\n" +
            "2. Plug it into the OBD-II port and turn the ignition on.\n" +
            "3. Pick the adapter, tap Connect, pick the engine, then Quick or Deep.\n\n" +
            "Deep scan = quick scan + warm-idle sensor and fuel trim analysis + CAN module sweep.\n" +
            "Only 'Clear codes' writes anything to the car."

        ensurePermissionAndLoad()
    }

    override fun onDestroy() {
        liveRunning = false
        link.close()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun engine(): Mercedes.Engine = Mercedes.ENGINES[engineSpinner.selectedItemPosition]

    private fun log(line: String) {
        runOnUiThread {
            report.append(line).append('\n')
            output.append(line + "\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun ensurePermissionAndLoad() {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            loadDevices()
        }
    }

    @SuppressLint("MissingPermission")
    private fun loadDevices() {
        val adapter: BluetoothAdapter? = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) { status.text = "This device has no Bluetooth."; return }
        if (!adapter.isEnabled) { status.text = "Turn Bluetooth on, then reopen the app."; return }
        devices = adapter.bondedDevices.toList().sortedBy { it.name ?: "" }
        if (devices.isEmpty()) { status.text = "No paired devices. Pair your OBD adapter first."; return }
        deviceSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            devices.map { (it.name ?: "Unknown") + "  " + it.address }
        )
        val last = getSharedPreferences("mbobd", Context.MODE_PRIVATE).getString("device", null)
        var idx = devices.indexOfFirst { it.address == last }
        if (idx < 0) idx = devices.indexOfFirst {
            val n = (it.name ?: "").uppercase()
            n.contains("OBD") || n.contains("ELM") || n.contains("VLINK") || n.contains("VGATE") || n.contains("KONNWEI")
        }
        if (idx >= 0) deviceSpinner.setSelection(idx)
    }

    @SuppressLint("MissingPermission")
    private fun connect() {
        val dev = devices.getOrNull(deviceSpinner.selectedItemPosition)
        if (dev == null) { status.text = "Pick a paired adapter first."; return }
        liveRunning = false
        status.text = "Connecting to ${dev.name}..."
        connectBtn.isEnabled = false
        io.execute {
            try {
                link.connect(dev)
                val ver = scanner.init()
                runOnUiThread { status.text = "Adapter: $ver. Looking for the engine ECU (ignition on)..." }
                val ok = scanner.connectEcu()
                if (ok) {
                    scanner.loadSupported()
                    getSharedPreferences("mbobd", Context.MODE_PRIVATE).edit().putString("device", dev.address).apply()
                }
                runOnUiThread {
                    connectBtn.isEnabled = true
                    if (ok) {
                        status.text = "Connected: $ver, ${scanner.protoDesc}"
                        listOf(quickBtn, deepBtn, liveBtn, clearBtn).forEach { it.isEnabled = true }
                    } else {
                        status.text = "Adapter connected but the ECU did not answer. Ignition on? Try again."
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    connectBtn.isEnabled = true
                    status.text = "Could not connect: ${ex.message ?: ex.javaClass.simpleName}"
                }
            }
        }
    }

    private fun runTask(clear: Boolean, block: () -> Unit) {
        liveRunning = false
        if (clear) {
            report.setLength(0)
            output.text = ""
        }
        io.execute {
            try {
                block()
            } catch (ex: Exception) {
                log("[ERROR] ${ex.message ?: ex.javaClass.simpleName}. Check the adapter connection and ignition.")
            }
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Clear fault codes?")
            .setMessage("This erases stored codes and freeze frame data and resets readiness monitors. Save a report first if you want a record. Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                runTask(false) {
                    val ok = scanner.clearCodes()
                    log(if (ok) "Codes cleared. Re-scan to confirm." else "ECU did not confirm the clear.")
                }
            }
            .show()
    }

    private fun share() {
        if (report.isEmpty()) {
            Toast.makeText(this, "Run a scan first.", Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Mercedes OBD scan report")
            putExtra(Intent.EXTRA_TEXT, report.toString())
        }
        startActivity(Intent.createChooser(i, "Share report"))
    }
}
