package com.example.mbobd

import java.io.ByteArrayOutputStream
import java.util.Locale

/** Standard OBD-II (SAE J1979) helpers: PID table, response parsing, DTC decoding. */
object Obd {
    class Pid(
        val id: Int,
        val name: String,
        val unit: String,
        val bytes: Int,
        val decode: (IntArray) -> Double
    )

    val PIDS = listOf(
        Pid(0x04, "Engine load", "%", 1) { it[0] * 100.0 / 255 },
        Pid(0x05, "Coolant temp", "C", 1) { it[0] - 40.0 },
        Pid(0x06, "STFT bank 1", "%", 1) { (it[0] - 128) * 100.0 / 128 },
        Pid(0x07, "LTFT bank 1", "%", 1) { (it[0] - 128) * 100.0 / 128 },
        Pid(0x08, "STFT bank 2", "%", 1) { (it[0] - 128) * 100.0 / 128 },
        Pid(0x09, "LTFT bank 2", "%", 1) { (it[0] - 128) * 100.0 / 128 },
        Pid(0x0B, "Intake MAP", "kPa", 1) { it[0].toDouble() },
        Pid(0x0C, "Engine speed", "rpm", 2) { (256 * it[0] + it[1]) / 4.0 },
        Pid(0x0D, "Vehicle speed", "km/h", 1) { it[0].toDouble() },
        Pid(0x0E, "Timing advance", "deg", 1) { it[0] / 2.0 - 64 },
        Pid(0x0F, "Intake air temp", "C", 1) { it[0] - 40.0 },
        Pid(0x10, "MAF", "g/s", 2) { (256 * it[0] + it[1]) / 100.0 },
        Pid(0x11, "Throttle", "%", 1) { it[0] * 100.0 / 255 },
        Pid(0x14, "O2 B1S1", "V", 1) { it[0] / 200.0 },
        Pid(0x15, "O2 B1S2", "V", 1) { it[0] / 200.0 },
        Pid(0x18, "O2 B2S1", "V", 1) { it[0] / 200.0 },
        Pid(0x19, "O2 B2S2", "V", 1) { it[0] / 200.0 },
        Pid(0x33, "Barometric", "kPa", 1) { it[0].toDouble() },
        Pid(0x42, "Module voltage", "V", 2) { (256 * it[0] + it[1]) / 1000.0 },
        Pid(0x46, "Ambient temp", "C", 1) { it[0] - 40.0 },
        Pid(0x5C, "Oil temp", "C", 1) { it[0] - 40.0 }
    )

    fun pid(id: Int): Pid? = PIDS.firstOrNull { it.id == id }

    fun f1(v: Double): String = String.format(Locale.US, "%.1f", v)

    private val HEX = Regex("[0-9A-F]+")
    private val INDEX = Regex("^([0-9A-F]):")

    /** Turns one adapter line into bytes, or null if it is not a hex data line. */
    fun parseLine(raw: String): ByteArray? {
        var s = raw.trim().uppercase()
        if (s.isEmpty()) return null
        s = s.replace(INDEX, "").replace(" ", "")
        if (s.isEmpty() || !s.matches(HEX) || s.length % 2 != 0) return null
        return ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** Groups response lines into messages (multi-frame "0:" "1:" lines are merged). */
    fun messages(lines: List<String>): List<ByteArray> {
        val out = ArrayList<ByteArrayOutputStream>()
        for (raw in lines) {
            val b = parseLine(raw) ?: continue
            val idx = INDEX.find(raw.trim().uppercase())?.groupValues?.get(1)
            if (idx != null && idx != "0" && out.isNotEmpty()) {
                out.last().write(b)
            } else {
                out.add(ByteArrayOutputStream().also { it.write(b) })
            }
        }
        return out.map { it.toByteArray() }
    }

    fun u(b: Byte): Int = b.toInt() and 0xFF

    /** First message whose first byte is (mode + 0x40) and, if given, whose second byte is pid. */
    fun find(msgs: List<ByteArray>, mode: Int, pid: Int? = null): ByteArray? =
        msgs.firstOrNull {
            it.isNotEmpty() && u(it[0]) == mode + 0x40 &&
                (pid == null || (it.size >= 2 && u(it[1]) == pid))
        }

    fun dtcString(a: Int, b: Int): String {
        val t = "PCBU"[(a and 0xC0) shr 6]
        val d = (a and 0x30) shr 4
        val n = a and 0x0F
        return String.format(Locale.US, "%c%d%X%02X", t, d, n, b)
    }

    /** Decodes a mode 03/07/0A response. CAN replies carry a count byte, legacy ones do not. */
    fun decodeDtcs(msg: ByteArray, isCan: Boolean): List<String> {
        val start = if (isCan) 2 else 1
        val res = ArrayList<String>()
        var i = start
        while (i + 1 < msg.size) {
            val a = u(msg[i]); val b = u(msg[i + 1])
            if (a != 0 || b != 0) res.add(dtcString(a, b))
            i += 2
        }
        return res
    }

    fun asciiFrom(bytes: ByteArray, from: Int): String {
        val sb = StringBuilder()
        for (i in from until bytes.size) {
            val c = u(bytes[i])
            if (c in 0x20..0x7E) sb.append(c.toChar())
        }
        return sb.toString().trim()
    }
}
