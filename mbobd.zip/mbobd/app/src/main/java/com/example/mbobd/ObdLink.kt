package com.example.mbobd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Bluetooth Classic (SPP) link to an ELM327-style adapter. */
class ObdLink {
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    val isConnected: Boolean get() = socket?.isConnected == true

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        close()
        var s: BluetoothSocket = device.createRfcommSocketToServiceRecord(SPP)
        try {
            s.connect()
        } catch (e: Exception) {
            // Many cheap adapters only work with the reflection fallback.
            try { s.close() } catch (_: Exception) {}
            val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            s = m.invoke(device, 1) as BluetoothSocket
            s.connect()
        }
        socket = s
        input = s.inputStream
        output = s.outputStream
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null; input = null; output = null
    }

    /** Sends one command and returns the non-empty response lines (echo removed). */
    @Synchronized
    fun send(cmd: String, timeoutMs: Long = 4000): List<String> {
        val out = output ?: throw IllegalStateException("Not connected")
        val inp = input ?: throw IllegalStateException("Not connected")
        while (inp.available() > 0) inp.read()
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val c = inp.read()
                if (c < 0) break
                if (c == '>'.code) break
                sb.append(c.toChar())
            } else {
                Thread.sleep(10)
            }
        }
        val echo = cmd.replace(" ", "")
        return sb.toString().split('\r', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.replace(" ", "").equals(echo, ignoreCase = true) }
    }

    companion object {
        private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}
