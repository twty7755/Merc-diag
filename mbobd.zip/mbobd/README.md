# MB M112/M113 Scan

Android app for a Bluetooth ELM327 OBD-II adapter, tuned for Mercedes M112 (V6) and M113 (V8) engines.

## Build the APK
**Android Studio:** open this folder, let Gradle sync, Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub (no Android Studio):** upload this folder (including `.github`) to a private repo, run "Build APK" from the Actions tab, download `mbobd-debug-apk` from the run.

## Use it
1. Pair the adapter in Android Bluetooth settings (PIN usually 1234 or 0000).
2. Plug into the OBD-II port, ignition on.
3. Open the app, pick the adapter, Connect, pick your engine.
4. Quick = VIN, calibration ID, MIL, readiness monitors, stored/pending/permanent codes with Mercedes hints, freeze frame.
5. Deep = Quick + warm-idle sensor and fuel-trim analysis + CAN module sweep.
6. Live = continuous data. Share report = send the last scan as text.

## Limits
- Bluetooth Classic (SPP) ELM327 adapters only. BLE-only adapters will not show up as pairable SPP devices.
- Standard OBD-II only for the engine. Mercedes-specific data (cam adjuster angles, misfire counters per cylinder, SAI details, other modules over pins other than 6/14) needs Mercedes' own protocol and is not covered.
- The module sweep needs 11-bit 500k CAN. Older K-line cars expose only the engine ECU through the OBD-II pins with an ELM327.
- O2 analysis reads PIDs 14/15/18/19 (B1S1, B1S2, B2S1, B2S2 in the usual two-bank layout). An ECU that reports its sensors in the four-bank layout will have bank 2 O2 analysis skipped, not misreported.
- Fault-code hints are general guidance for these engine families; confirm against WIS/STAR.
- Cheap clone adapters can be unreliable. If connection fails, unplug the adapter for a minute and retry.
- Clear codes is the only action that writes to the car.
